// Example project data

const projects = [

  {

    title: "Portfolio Website",

    description: "A personal portfolio built with HTML, CSS, and JavaScript.",

    link: "#"

  },

  {

    title: "To-Do App",

    description: "A simple to-do list application using local storage.",

    link: "#"

  },

  {

    title: "Weather App",

    description: "Fetches real-time weather data using a public API.",

    link: "#"

  }

];

// Dynamically render projects

document.addEventListener('DOMContentLoaded', () => {

  const container = document.getElementById('project-container');

  projects.forEach(project => {

    const card = document.createElement('div');

    card.className = 'project-card';

    card.innerHTML = `

      <h3>${project.title}</h3>

      <p>${project.description}</p>

      <a href="${project.link}" target="_blank">View Project</a>

    `;

    container.appendChild(card);

  });

});